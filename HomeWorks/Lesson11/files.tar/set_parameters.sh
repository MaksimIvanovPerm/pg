#!/bin/bash

source /var/lib/postgresql/lesson8/library
set_parameters "$@"
