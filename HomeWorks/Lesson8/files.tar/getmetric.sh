#!/bin/bash
source /var/lib/postgresql/lesson8/library 
get_test_metric "$@"
